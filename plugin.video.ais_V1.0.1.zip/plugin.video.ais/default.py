#!/usr/bin/env python
# -*-mode: python; coding: utf-8 -*-
import sys
import xbmcplugin
import xbmcgui
import xbmc
import xbmcaddon
import requests
import re
import os
import urllib
import time
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.ais'
Oo0Ooo = xbmcaddon . Addon ( id = OO0o )
O0O0OO0O0O0 = xbmc . translatePath ( 'special://home/addons/' + str ( OO0o ) + '/' )
iiiii = os . path . join ( O0O0OO0O0O0 , 'm3ucache' , 'temp.m3u' )
ooo0OO = os . path . join ( O0O0OO0O0O0 , 'm3ucache' )
if not os . path . exists ( ooo0OO ) :
 os . makedirs ( ooo0OO )
II1 = os . path . join ( O0O0OO0O0O0 , 'm3ucache' , 'logo.txt' )
O00ooooo00 = os . path . join ( O0O0OO0O0O0 , 'icon.png' )
I1IiiI = os . path . join ( O0O0OO0O0O0 , 'fanart.jpg' )
IIi1IiiiI1Ii = Oo0Ooo . getSetting ( 'username' )
I11i11Ii = Oo0Ooo . getSetting ( 'password' )
oO00oOo = xbmcgui . Dialog ( )
OOOo0 = xbmcgui . DialogProgress ( )
if 54 - 54: i1 - o0 * i1oOo0OoO * iIIIiiIIiiiIi % Oo
o0O = Oo0Ooo . getSetting ( "epg" )
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
O0oOO0o0 = 'http://streamsmax.eu:8080/get.php?username=' + IIi1IiiiI1Ii + '&password=' + I11i11Ii + '&type=m3u_plus&output=ts'
i1ii1iIII = 'http://streamsmax.eu:8080/xmltv.php?username=' + IIi1IiiiI1Ii + '&password=' + I11i11Ii + '&type=m3u_plus&output=ts'
if 59 - 59: II1i * o00ooo0 / o00 * Oo0oO0ooo
if 56 - 56: ooO00oOoo - O0OOo
def II1Iiii1111i ( string ) :
 if len ( string ) == 1 :
  string = '0' + string
 return string
 if 25 - 25: OOo000
def O0 ( ) :
 I11i1i11i1I = time . gmtime ( )
 Iiii = re . findall ( 'time.struct_time\(tm_year=(.+?), tm_mon=(.+?), tm_mday=(.+?), tm_hour=(.+?), tm_min=(.+?), .+?tm_isdst=(.+?)\)' , str ( I11i1i11i1I ) )
 for OOO0O , oo0ooO0oOOOOo , oO000OoOoo00o , iiiI11 , OOooO , OOoO00o in Iiii :
  oo0ooO0oOOOOo = II1Iiii1111i ( oo0ooO0oOOOOo ) ; oO000OoOoo00o = II1Iiii1111i ( oO000OoOoo00o ) ; iiiI11 = II1Iiii1111i ( iiiI11 ) ; OOooO = II1Iiii1111i ( OOooO )
  if OOoO00o == '0' :
   iiiI11 = int ( iiiI11 ) + 1
 II111iiii = OOO0O + oo0ooO0oOOOOo + oO000OoOoo00o + str ( iiiI11 ) + OOooO
 return II111iiii
 if 48 - 48: I1Ii . IiIi1Iii1I1 - IiIi1Iii1I1 % IiIi1Iii1I1 - o00ooo0 * Oo0oO0ooo
def O00OooO0 ( name , url , icon , schedule = False ) :
 Ooooo = ''
 name = name . split ( ' -' ) [ 0 ]
 o00o = [ ]
 OOOo0 . create ( 'AIS' , 'Fetching EPG Data' )
 II111iiii = O0 ( )
 IiI1I1 = open ( iiiii ) . read ( )
 IiI1I1 = IiI1I1 . replace ( '>USERNAME<' , IIi1IiiiI1Ii ) . replace ( '>PASSWORD<' , I11i11Ii )
 OoO000 = re . findall ( '#EXTINF(.+?)\n' , IiI1I1 )
 for IIiiIiI1 in OoO000 :
  iiIiIIi = re . findall ( 'name="(.+?)"' , IIiiIiI1 ) [ 0 ]
  if iiIiIIi == name :
   Ooooo = re . findall ( 'tvg-id="(.+?)"' , IIiiIiI1 ) [ 0 ]
 if Ooooo != '' :
  ooOoo0O = OooO0 ( )
  II11iiii1Ii = re . findall ( 'start="(.+?)" stop="(.+?)" channel="(.+?)".+?><title>(.+?)</title><desc>(.+?)/desc>' , ooOoo0O , re . DOTALL )
  OO0oOoo = 0
  OOOo0 . update ( 0 , 'Creating EPG List' )
  for O0o0Oo , Oo00OOOOO , O0O , O00o0OO , I11i1 in II11iiii1Ii :
   I11i1 = I11i1 . replace ( '<' , '' ) . replace ( '&apos;' , '' ) . replace ( '\\/' , '/' )
   if Ooooo == O0O :
    iIi1ii1I1 = O0o0Oo [ 6 : 8 ] + '/' + O0o0Oo [ 4 : 6 ]
    o0I11II1i = O0o0Oo [ 6 : 8 ] + '/' + O0o0Oo [ 4 : 6 ] + ' ' + O0o0Oo [ 8 : 10 ] + ':' + O0o0Oo [ 10 : 12 ]
    IIIII = time . strptime ( O0o0Oo [ 6 : 8 ] + '/' + O0o0Oo [ 4 : 6 ] , "%d/%m" )
    ooooooO0oo = time . strptime ( II111iiii [ 6 : 8 ] + '/' + II111iiii [ 4 : 6 ] , "%d/%m" )
    if IIIII < ooooooO0oo :
     pass
    else :
     o00o . append ( [ O0O , O00o0OO , I11i1 , o0I11II1i , O0o0Oo [ 0 : 4 ] ] )
 if schedule == True :
  for IIiiiiiiIi1I1 in o00o :
   iiIiIIi = IIiiiiiiIi1I1 [ 3 ] + ' | ' + IIiiiiiiIi1I1 [ 1 ] . replace ( '&apos;' , '' ) + '                                                                                                                            *' + IIiiiiiiIi1I1 [ 3 ] + '*'
   try :
    o0I11II1i = str ( IIiiiiiiIi1I1 [ 3 ] )
    if time . gmtime ( ) < time . strptime ( IIiiiiiiIi1I1 [ 4 ] + '/' + o0I11II1i , '%Y/%d/%m %H:%M' ) :
     I1IIIii ( iiIiIIi . replace ( '&amp;' , '&' ) , url , 6 , icon , '' , IIiiiiiiIi1I1 [ 2 ] )
   except :
    pass
 elif schedule == False :
  oO00oOo . textviewer (
 "EPG Data for " + name , '\n' . join ( o0I11II1i + '\n' + O00o0OO + '\n' + I11i1 + '\n\n' for O0O , O00o0OO ,
 I11i1 , o0I11II1i , time_ in o00o if time . gmtime ( ) < time . strptime ( time_ + '/' + o0I11II1i , '%Y/%d/%m %H:%M' ) ) )
  if 95 - 95: I1Ii111 % o00ooo0 . i1
def I1i1I ( ) :
 I1IIIii ( 'Update Channel List' , '' , 3 , '' , '' )
 I1IIIii ( 'Search Channel' , '' , 4 , '' , '' )
 I1IIIii ( 'Live TV' , '' , 7 , '' , '' )
 I1IIIii ( 'Movies' , '' , 7 , '' , '' )
 I1IIIii ( 'TV Shows' , '' , 7 , '' , '' )
 if 80 - 80: ooOoO0o - I1Ii111
def OOO00 ( name ) :
 if name == 'Live TV' :
  I1IIIii ( 'All channels' , '' , 1 , '' , '' )
  iiiiiIIii = [ '24/7 Channels' , 'UK | Entertainment' , 'UK | Regionals' , 'UK | Plus 1' , 'UK | Documentary' , 'Bookies' , 'UK | Shopping' , 'UK | News' ,
 'UK | Movies' , 'UK | Kids' , 'UK | Music' , 'UK | Irish TV' , 'UK | Sky Sports' , 'UK | BT Sports' , 'UK | Asian Indian channels' ,
 'Deluxe PPV Hub' , 'Deluxe EPL Hub' , 'Deluxe EFL Hub' , 'Radio' , 'Deluxe SPFL Hub' , 'UFC Fight Pass' , 'Deluxe NFL Hub' ,
 'ESPN Plus Channels' , 'BR Live (Champians League)' , 'Deluxe NRL/AFL Hub' , 'Deluxe MBL Hub' , 'UK | Sports' , 'Rugby Pass' , 'Canadian_Sports' ,
 'World Sports' , 'Club TV' , 'Fox Match Pass' , 'USA | Documentaries' , 'USA | Entertainment' , 'USA | Kids' , 'USA | Movies' , 'USA | News & info' ,
 'USA | Music Choice' , 'UFC on ESPN' , 'World Soccer Match Pass' , 'Bein Sports' , 'Supersports Channels' , 'Canadian Channels' , 'For Adults' , 'WWE Smackdown']
 elif name == 'Movies' :
  iiiiiIIii = [ '2020 Movies' , 'Latest Releases' , 'Comedy' , 'Action' , 'Crime' , 'Adventure' , 'Horror' , 'Fantasy' , 'Thriller' , 'Drama' , 'Family' , 'Science Fiction' , 'Romance' , 'Music' , 'War' , 'History' , 'Documentary' , 'Western' , 'Mystery' , 'TV Movie' , 'Christmas Movies' , 'PPV Repeats' , 'Stand Up Comedy' , 'Fitness' , 'WWE RAW'  ]
 elif name == 'TV Shows' :
  iiiiiIIii = [ 'Action & Adventure' , 'Kids' , 'Reality' , 'Sci-Fi & Fantasy' , 'War & Politics' , 'Talk' , 'Soaps' , 'unknown' , 'Boxsets' , 'Bellator']
 for O000OO0 in iiiiiIIii :
  try :
   if 'a-z' in O000OO0 . lower ( ) :
    I1IIIii ( O000OO0 , '' , 6 , '' , '' )
   else :
    I1IIIii ( O000OO0 , '' , 1 , '' , '' )
  except :
   pass
   if 43 - 43: I1Ii - i1 % iII111i . Oo0oO0ooo
def o00OooOooo ( name ) :
 if 'movie' in name . lower ( ) :
  iiiiiIIii = [ 'Movies 0-9' , 'Movies A-D' , 'Movies E-H' , 'Movies I-L' , 'Movies M-P' , 'Movies Q-T' , 'Movies U-Z' ]
 elif 'tv' in name . lower ( ) :
  iiiiiIIii = [ "TV Shows 'A'" , "TV Shows 'B'" , "TV Shows 'C'" , "TV Shows 'D'" , "TV Shows 'E'" , "TV Shows 'F'" , "TV Shows 'G'" , "TV Shows 'H'" ,
 "TV Shows 'I'" , "TV Shows 'J'" , "TV Shows 'K'" , "TV Shows 'L'" , "TV Shows 'M'" , "TV Shows 'N'" , "TV Shows 'O'" , "TV Shows 'P'" , "TV Shows 'Q'" ,
 "TV Shows 'R'" , "TV Shows 'S'" , "TV Shows 'T'" , "TV Shows 'U'" , "TV Shows 'V'" , "TV Shows 'W'" , "TV Shows 'X'" , "TV Shows 'Y'" , "TV Shows 'Z'" ,
 'TV Shows 0-9' ]
 for O000OO0 in iiiiiIIii :
  try :
   I1IIIii ( O000OO0 , '' , 1 , '' , '' )
  except :
   pass
   if 97 - 97: IiIi1Iii1I1 - o00 * i11iIiiIii / ooOoO0o % I1Ii - i1oOo0OoO
def OoOo00o ( ) :
 o0OOoo0OO0OOO = xbmcgui . Dialog ( ) . input ( 'Search' , type = xbmcgui . INPUT_ALPHANUM )
 IiI1I1 = open ( iiiii ) . read ( )
 IiI1I1 = IiI1I1 . replace ( '>USERNAME<' , IIi1IiiiI1Ii ) . replace ( '>PASSWORD<' , I11i11Ii )
 OoO000 = re . findall ( '#EXTINF(.+?)\n(.+?)\n' , IiI1I1 )
 for IIiiIiI1 , iI1iI1I1i1I in OoO000 :
  iI1iI1I1i1I = iI1iI1I1i1I . strip ( )
  iiIiIIi = re . findall ( 'name="(.+?)"' , IIiiIiI1 ) [ 0 ]
  iIi11Ii1 = re . findall ( 'tvg-logo="(.+?)"' , IIiiIiI1 ) [ 0 ]
  Ii11iII1 = re . findall ( 'group-title="(.+?)"' , IIiiIiI1 ) [ 0 ]
  if iIi11Ii1 [ 0 ] == '"' or 'base64' in iIi11Ii1 :
   iIi11Ii1 = O00ooooo00
  if o0OOoo0OO0OOO . lower ( ) . replace ( ' ' , '' ) in iiIiIIi . lower ( ) . replace ( ' ' , '' ) :
   I1IIIii ( iiIiIIi , iI1iI1I1i1I , 2 , iIi11Ii1 , '' , '' )
   if 51 - 51: Oo * I1Ii111 % o00O0oo * Oo % II1i / IiIi1Iii1I1
def iIIIIii1 ( Category ) :
 o00o = [ ]
 IiI1I1 = open ( iiiii ) . read ( )
 IiI1I1 = IiI1I1 . replace ( '>USERNAME<' , IIi1IiiiI1Ii ) . replace ( '>PASSWORD<' , I11i11Ii )
 OoO000 = re . findall ( '#EXTINF(.+?)\n(.+?)\n' , IiI1I1 )
 if o0O == 'true' :
  OOOo0 . create ( 'AIS' , 'Fetching EPG Data' )
  ooOoo0O = OooO0 ( )
  II11iiii1Ii = re . findall ( 'start="(.+?)" stop="(.+?)" channel="(.+?)".+?><title>(.+?)</title><desc>(.+?)</desc>' , ooOoo0O , re . DOTALL )
  OO0oOoo = 0
  OOOo0 . update ( 0 , 'Creating EPG List' )
  for O0o0Oo , Oo00OOOOO , O0O , O00o0OO , I11i1 in II11iiii1Ii :
   II111iiii = O0 ( )
   oo000OO00Oo = O0o0Oo . replace ( '+0100' , '' ) . replace ( ' ' , '' ) [ : 12 ]
   O0OOO0OOoO0O = Oo00OOOOO . replace ( '+0100' , '' ) . replace ( ' ' , '' ) [ : 12 ]
   if oo000OO00Oo < II111iiii < O0OOO0OOoO0O :
    o00o . append ( [ O0O , O00o0OO , I11i1 ] )
    OOOo0 . update ( 0 , 'Created EPG List' )
 for IIiiIiI1 , iI1iI1I1i1I in OoO000 :
  iI1iI1I1i1I = iI1iI1I1i1I . strip ( )
  Ooooo = re . findall ( 'tvg-id="(.+?)"' , IIiiIiI1 ) [ 0 ]
  iiIiIIi = re . findall ( 'name="(.+?)"' , IIiiIiI1 ) [ 0 ]
  iIi11Ii1 = re . findall ( 'tvg-logo="(.+?)"' , IIiiIiI1 ) [ 0 ]
  try :
   Ii11iII1 = re . findall ( 'group-title="(.+?)"' , IIiiIiI1 ) [ 0 ]
   O00Oo000ooO0 = iiIiIIi
   if o0O == 'true' :
    OO0oOoo += 1
    if OOOo0 . iscanceled ( ) :
     return
    OOOo0 . update ( ( len ( OoO000 ) / OO0oOoo ) * 100 , "Getting info for {}" . format ( iiIiIIi ) )
    for IIiiiiiiIi1I1 in o00o :
     if 100 - 100: i1 + OOo000 - o00 + i11iIiiIii * ooO00oOoo
     if Ooooo == IIiiiiiiIi1I1 [ 0 ] :
      O00Oo000ooO0 = iiIiIIi + '\n' + IIiiiiiiIi1I1 [ 1 ] + '\n' + IIiiiiiiIi1I1 [ 2 ]
      O00Oo000ooO0 = O00Oo000ooO0 . replace ( '&apos;' , '' )
      iiIiIIi = iiIiIIi + ' - ' + IIiiiiiiIi1I1 [ 1 ] . replace ( '&apos;' , '' )
      if 30 - 30: o00O0oo . ooO00oOoo - i1oOo0OoO
      if 8 - 8: iIIIiiIIiiiIi - o0 * Oo + i11iIiiIii / I1Ii % o00
  except :
   pass
  if iIi11Ii1 [ 0 ] == '"' or 'base64' in iIi11Ii1 :
   iIi11Ii1 = O00ooooo00
  if Category == 'Full_List' :
   try :
    I1IIIii ( iiIiIIi , iI1iI1I1i1I , 2 , iIi11Ii1 , '' , O00Oo000ooO0 )
   except :
    pass
  elif Ii11iII1 == Category :
   try :
    I1IIIii ( iiIiIIi , iI1iI1I1i1I , 2 , iIi11Ii1 , '' , O00Oo000ooO0 )
   except :
    pass
    if 16 - 16: II1i + I1Ii111 - Oo
def oOoOO0 ( ) :
 if 30 - 30: Oo - o00 - i11iIiiIii % ooOoO0o - Oo * ooO00oOoo
 oO00O0O0O = os . path . join ( O0O0OO0O0O0 , 'm3ucache' , 'epg.txt' )
 i1ii1iiI = ''
 II111iiii = O0 ( )
 oO000OoOoo00o = II111iiii [ 6 : 8 ] ; oo0ooO0oOOOOo = II111iiii [ 4 : 6 ]
 O0o0O00Oo0o0 = { 'User-Agent' : 'Mozilla/5.0 (Windows NT 6.3; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0' }
 O00O0oOO00O00 = requests . get ( i1ii1iIII , headers = O0o0O00Oo0o0 ) . text
 IIiiIiI1 = '<day>' + oO000OoOoo00o + '</day><month>' + oo0ooO0oOOOOo + '</month>\n'
 i1ii1iiI += IIiiIiI1
 i1ii1iiI += O00O0oOO00O00
 i1Oo00 = open ( oO00O0O0O , 'w+' )
 i1Oo00 . write ( i1ii1iiI . encode ( 'UTF-8' ) )
 i1Oo00 . close ( )
 O00O0oOO00O00 = open ( oO00O0O0O ) . read ( )
 return O00O0oOO00O00
 if 31 - 31: I1Ii . ooOoO0o / i1
def OooO0 ( ) :
 if 89 - 89: ooOoO0o
 oO00O0O0O = os . path . join ( O0O0OO0O0O0 , 'm3ucache' , 'epg.txt' )
 II111iiii = O0 ( )
 oO000OoOoo00o = II111iiii [ 6 : 8 ] ; oo0ooO0oOOOOo = II111iiii [ 4 : 6 ]
 if not os . path . exists ( oO00O0O0O ) :
  O00O0oOO00O00 = oOoOO0 ( )
 else :
  OO0oOoOO0oOO0 = open ( oO00O0O0O ) . read ( )
  oO0OOoo0OO , O0ii1ii1ii = re . findall ( '<day>(.+?)</day><month>(.+?)</month>' , str ( OO0oOoOO0oOO0 ) ) [ 0 ]
  if oO0OOoo0OO == oO000OoOoo00o and O0ii1ii1ii == oo0ooO0oOOOOo :
   O00O0oOO00O00 = open ( oO00O0O0O ) . read ( )
  else :
   O00O0oOO00O00 = oOoOO0 ( )
 return O00O0oOO00O00
def oooooOoo0ooo ( ) :
 O00O0oOO00O00 = requests . get ( O0oOO0o0 ) . content
 O00O0oOO00O00 = O00O0oOO00O00 . replace ( IIi1IiiiI1Ii , '>USERNAME<' ) . replace ( I11i11Ii , '>PASSWORD<' )
 I1I1IiI1 = re . findall ( '(.+?)\n' , O00O0oOO00O00 )
 if str ( O00O0oOO00O00 ) == '' :
  III1iII1I1ii ( 'no data recieved' , 'Would you like to double check username and password in settings?' , '' , 'open_settings' )
 else :
  oOOo0 = open ( iiiii , 'w+' )
  oo00O00oO = open ( iiiii , 'a' )
  oo00O00oO . write ( '\n' . join ( str ( line ) for line in I1I1IiI1 ) )
 xbmc . executebuiltin ( "XBMC.Container.Refresh" )
 if 23 - 23: I1Ii111 + I1Ii111 . o00
def III1iII1I1ii ( title , message1 , message2 , action ) :
 if oO00oOo . yesno ( title , message1 , message2 ) :
  if action == 'open_settings' :
   Oo0Ooo . openSettings ( sys . argv [ 0 ] )
   if 38 - 38: I1Ii
def I1IIIii ( name , url , mode , iconimage , fanart , Folder = True ) :
 name = name . strip ( )
 if '\t' in name : name = name . replace ( '\t' , ' ' )
 Ii1 = [ 'mp4' , 'mkv' , 'm3u' , 'avi' ]
 for IIiiiiiiIi1I1 in Ii1 :
  if IIiiiiiiIi1I1 in url :
   Folder = False
 if mode == 2 : Folder = False
 if mode == 3 : Folder = False
 if mode == 2 :
  if iconimage == '' or iconimage == '.' or iconimage == ' ' :
   try :
    OO0oOoOO0oOO0 = open ( II1 ) . read ( )
    OOooOO000 = name . lower ( ) . replace ( 'fhd' , '' ) . replace ( 'backup' , '' ) . replace ( ' ' , '' ) . replace ( 'sd' , '' )
    OOooOO000 = OOooOO000 . split ( '*' ) [ 0 ] . split ( ':' ) [ 1 ] . split ( '-' ) [ 0 ]
    II11iiii1Ii = re . findall ( '(.+?): (.+?)\n' , OO0oOoOO0oOO0 )
    for OOoOoo , oO0000OOo00 in II11iiii1Ii :
     if OOooOO000 . lower ( ) . replace ( ' ' , '' ) in OOoOoo . lower ( ) . replace ( ' ' , '' ) :
      iconimage = oO0000OOo00
   except : iconimage = O00ooooo00
 if iconimage == '' : iconimage = O00ooooo00
 elif iconimage == ' ' : iconimage = O00ooooo00
 if fanart == '' : fanart = I1IiiI
 elif fanart == ' ' : fanart = I1IiiI
 iiIi1IIiIi = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus (
 name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 oOO00Oo = True
 i1iIIIi1i = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1iIIIi1i . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 i1iIIIi1i . setProperty ( "Fanart_Image" , fanart )
 oOO00Oo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiIi1IIiIi , listitem = i1iIIIi1i , isFolder = Folder )
 return oOO00Oo
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 43 - 43: ooOoO0o % o00
def iiiiiiii1 ( name , url ) :
 xbmc . Player ( ) . play ( url , xbmcgui . ListItem ( name ) )
 if 18 - 18: o00O0oo % O0OOo * i1
def o0O0Oooo0O ( ) :
 O0o = [ ]
 OoOooO = sys . argv [ 2 ]
 if len ( OoOooO ) >= 2 :
  II111iiiI1Ii = sys . argv [ 2 ]
  o0O0OOO0Ooo = II111iiiI1Ii . replace ( '?' , '' )
  if ( II111iiiI1Ii [ len ( II111iiiI1Ii ) - 1 ] == '/' ) :
   II111iiiI1Ii = II111iiiI1Ii [ 0 : len ( II111iiiI1Ii ) - 2 ]
  iiIiI = o0O0OOO0Ooo . split ( '&' )
  O0o = { }
  for I1 in range ( len ( iiIiI ) ) :
   OOO00O0O = { }
   OOO00O0O = iiIiI [ I1 ] . split ( '=' )
   if ( len ( OOO00O0O ) ) == 2 :
    O0o [ OOO00O0O [ 0 ] ] = OOO00O0O [ 1 ]
    if 33 - 33: i1 . OOo000 . iII111i
 return O0o
 if 72 - 72: iIIIiiIIiiiIi / I1Ii111 + i1oOo0OoO - IiII
II111iiiI1Ii = o0O0Oooo0O ( )
iI1Iii = None
oO00OOoO00 = ''
IiI111111IIII = None
i1Ii = None
ii111iI1iIi1 = None
if 78 - 78: I1Ii111 . o00 + I1Ii111 / Oo0oO0ooo / I1Ii111
try :
 iI1Iii = urllib . unquote_plus ( II111iiiI1Ii [ "url" ] )
except :
 pass
try :
 oO00OOoO00 = urllib . unquote_plus ( II111iiiI1Ii [ "name" ] )
except :
 pass
try :
 IiI111111IIII = urllib . unquote_plus ( II111iiiI1Ii [ "iconimage" ] )
except :
 pass
try :
 i1Ii = int ( II111iiiI1Ii [ "mode" ] )
except :
 pass
try :
 ii111iI1iIi1 = urllib . unquote_plus ( II111iiiI1Ii [ "fanart" ] )
except :
 pass
try :
 O00Oo000ooO0 = urllib . unquote_plus ( II111iiiI1Ii [ "description" ] )
except :
 pass
 if 54 - 54: ooOoO0o % O0OOo
if not os . path . exists ( iiiii ) and IIi1IiiiI1Ii != '' and I11i11Ii != '' : oooooOoo0ooo ( )
elif IIi1IiiiI1Ii == '' and I11i11Ii == '' : III1iII1I1ii ( 'No username or password present' , 'Would you like to input username and password in settings?' , '' , 'open_settings' )
elif i1Ii == None : I1i1I ( )
elif i1Ii == 1 : iIIIIii1 ( oO00OOoO00 )
elif i1Ii == 2 : iiiiiiii1 ( oO00OOoO00 , iI1Iii )
elif i1Ii == 3 : oooooOoo0ooo ( )
elif i1Ii == 4 : OoOo00o ( )
elif i1Ii == 5 : O00OooO0 ( oO00OOoO00 , iI1Iii , O00ooooo00 )
elif i1Ii == 6 : o00OooOooo ( oO00OOoO00 )
elif i1Ii == 7 : OOO00 ( oO00OOoO00 )
if 37 - 37: ooOoO0o * IiII / IiIi1Iii1I1 - O0OOo % Oo . o00ooo0
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) ) 
